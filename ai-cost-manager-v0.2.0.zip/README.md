# AI 成本管家（Token Usage Monitor）

Windows 桌面 AI 用量与成本监控组件。它把 DeepSeek 余额、本地请求记录、Codex / Hermes / WorkBuddy 状态和自动化任务汇总到一个常驻小窗与本地看板中。

> 当前版本是 Windows 专用、local-first 的个人工作台版本。所有数据只在本机处理，服务仅监听 `127.0.0.1`。

![AI 成本管家演示](docs/demo-dashboard.png)

![API 服务商设置](docs/provider-settings.png)

## 功能

- 多 API 服务商：DeepSeek、OpenRouter、OpenAI、Anthropic、Google Gemini、自定义兼容接口\n- 自动识别或手动选择服务商，测试连接并保存多个 Key\n- DeepSeek / OpenRouter 余额；其他服务商连接与模型状态\n- 今日 / 本月 / 累计费用
- 近 7 日费用、余额可用天数和余额快照趋势
- 今日 24 小时分时费用
- Codex / Hermes 的 token 与费用明细
- WorkBuddy 积分、最近会话和自动化状态
- 今日用量最高的 AI 及当前工作内容
- 余额不足、费用异常、数据断流、自动化异常提醒
- 无边框桌面小组件、置顶、收起贴边、位置记忆
- 浏览器完整面板：`http://127.0.0.1:8756/`

## 演示模式

不需要 API Key，也不会读取本机真实数据。双击：

```text
start_demo.bat
```

演示服务使用独立配置 `demo.config.json` 和合成数据，打开后可直接查看费用趋势、模型明细、AI 工作状态和系统告警。

## Windows EXE

使用本机打包脚本生成无需安装 Python 的单文件 EXE：

```powershell
.\build_exe.ps1
```

输出文件：

```text
dist\AICostManager.exe
```

EXE 需要 Windows 10/11 64 位和 Microsoft Edge WebView2 Runtime。v0.2.0 暂未做商业代码签名，首次运行可能出现 SmartScreen 提示。

## 安装

要求：

- Windows 10/11
- Python 3.10+
- `pythonw` 已加入 PATH

首次安装：

```powershell
python install.py
```

双击 `start.bat` 启动。第一次运行会进入 API 设置页，可选择服务商、修改 Base URL 并测试连接。也可以使用环境变量：

```powershell
$env:DEEPSEEK_API_KEY = "你的 Key"
python app.py
```

也可以先自行创建配置：

```powershell
Copy-Item .\config.example.json .\config.json
```

完整面板地址：

```text
http://127.0.0.1:8756/
```

## 配置

`config.example.json` 是模板，程序运行后会生成 `config.json`。

常用字段：

| 字段 | 说明 |
|---|---|
| `api_key` | 旧版 DeepSeek Key 兼容字段；新配置优先使用 `providers` |\n| `providers` | 多服务商数组，保存类型、Base URL、Key 和启用状态 |
| `demo_mode` | `true` 时启用无 Key 的合成演示数据 |
| `port` | 本地服务端口，默认 `8756` |
| `usage_path` | cc-switch 的 `usage.jsonl` 路径 |
| `pricing_path` | 自定义模型价格文件 |
| `codex_db` | Codex 本地 SQLite 数据库 |
| `workbuddy_db` | WorkBuddy 本地数据库 |
| `workbuddy_audit_dir` | WorkBuddy 审计日志目录 |
| `hermes_metrics` | Hermes 本地指标数据库 |
| `balance_history` | 余额快照文件 |
| `refresh_ms` | 界面刷新间隔 |
| `schedule_dir` | 工作日程目录，可留空 |

路径支持 `~` 和环境变量。默认依据当前 Windows 用户目录推导，不再写死个人路径。

如果需要自定义价格，复制示例文件：

```powershell
Copy-Item .\usage_pricing.example.json .\usage_pricing.json
```

## 隐私与安全

- `config.json` 含 API Key，已被 `.gitignore` 排除。
- `usage.jsonl`、数据库、余额历史和窗口状态不会提交。
- 服务只绑定 `127.0.0.1`，不对外网开放。
- API Key 只用于请求 DeepSeek 官方接口，不从本仓库读取或上传其他服务密钥。
- 换电脑或分享前，确认仓库里没有 `config.json`、`.env`、本地数据库和个人日志。

## 目录

```text
token-usage-monitor/
├─ server.py                 # 本地 HTTP 服务与数据聚合
├─ app.py                    # 单入口启动器
├─ widget_host.py            # pywebview 桌面壳
├─ widget.html               # 常驻小组件
├─ dashboard.html            # 完整看板
├─ setup.html                # 首次连接设置
├─ install.py                # 安装与配置生成
├─ build_exe.ps1             # PyInstaller 打包脚本
├─ version_info.txt          # EXE 版本信息
├─ start.bat                 # Windows 正式启动入口
├─ start_demo.bat            # 无 Key 演示入口
├─ demo.config.json          # 演示配置
├─ config.example.json       # 配置模板
├─ usage_pricing.example.json
├─ splash.png
├─ assets/ai-cost-manager.ico # 应用图标
├─ scripts/make_assets.py    # 品牌图与图标生成
├─ docs/demo-dashboard.png   # 演示截图
└─ SKILL.md                  # Codex 技能说明
```

## 作为 Codex 技能使用

把整个仓库目录放到：

```text
%USERPROFILE%\.codex\skills\token-usage-monitor\
```

确保根目录存在 `SKILL.md`，重启 Codex 后即可被识别。

## 当前限制

- v0.2.0 的 EXE 尚未做商业代码签名。

- 仅支持 Windows。
- 数据源针对 cc-switch、Codex、Hermes、WorkBuddy 的本地结构。
- 不同版本工具的数据库字段变化可能导致部分卡片不可用。
- OpenAI、Anthropic 和 Gemini 的普通 API Key 通常只能验证连接，官方不一定提供余额接口。\n- 目前不是多用户或团队 SaaS，不能跨机器汇总数据。

## 许可证

专有软件，未经书面许可不得复制、转售或再分发。见 `LICENSE`。
@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "TOKEN_MONITOR_CONFIG=%~dp0demo.config.json"
start "" "%~dp0AICostManager.exe"
exit /b 0
---
name: token-usage-monitor
description: 安装、运行、配置或排查 Windows 本地 AI 用量与成本监控组件，汇总 DeepSeek 余额与费用、Codex/Hermes/WorkBuddy 状态、自动化任务和本地成本告警。
---

# Token Usage Monitor

## 何时使用

用户要求以下任一事项时使用本技能：

- 安装或启动 AI 用量监控小组件
- 查看 DeepSeek 余额、费用或余额可用天数
- 配置 Codex、Hermes、WorkBuddy 或 cc-switch 的本地数据源
- 排查看板空白、数据显示异常或端口冲突
- 修改小组件样式、窗口行为或告警阈值
- 将本工具作为 Codex 技能安装

## 安全规则

1. API Key 只使用用户在设置页手动填写的值；不扫描其他程序配置、环境变量或日志中的 Key。
2. 不把 `config.json`、`.env`、`usage.jsonl`、数据库、余额历史和个人日志加入 Git。
3. 需要展示密钥状态时，只显示遮罩值或 `has_key: true/false`。
4. 修改后先运行语法检查，再启动本地服务验证健康接口。
5. 服务必须继续只监听 `127.0.0.1`，不得改成公网监听。

## 安装与授权

v0.3.2 起采用 7 天免费试用，之后为 6.60 元单机买断。支付宝收款账户为 `16607693636`，激活页同时提供微信经营收款码。联系 QQ `654115813`，邮箱 `654115813@qq.com`。首次运行需要在激活页查看机器码；付款后把机器码和订单号发到 QQ 或邮箱换取离线许可证。

```powershell
python install.py
.\start.bat
```

无 Key 演示：

```text
start_demo.bat
```

Windows EXE 构建：

```powershell
.\build_exe.ps1
```

如果 `pythonw` 不在 PATH，先安装 Python 3.10+ 并勾选“Add Python to PATH”。

## 配置

首次运行进入“API 设置”页，手动选择服务商、填写 Base URL 和 API Key，先测试连接再保存。密钥只写入本机 `config.json` 的 `providers` 数组。本工具不扫描其他程序配置、环境变量或日志来查找 API Key。

所有数据源路径支持 `~` 和环境变量。

## 验证

```powershell
python -m py_compile server.py app.py widget_host.py install.py licensing.py
Invoke-RestMethod http://127.0.0.1:8756/health
Invoke-RestMethod http://127.0.0.1:8756/api/license
```

期望结果：

```json
{"ok":true}
```

## 常见故障

### `/health` 无法连接

- 检查端口是否被占用：`Get-NetTCPConnection -LocalPort 8756`
- 检查 `pythonw` 是否可执行
- 查看启动时是否已经存在服务实例

### 页面有界面但没有数据

- 确认 `usage_path`、`codex_db`、`workbuddy_db`、`hermes_metrics` 指向本机真实文件
- 确认对应工具已经产生过至少一条本地记录
- 不要用示例数据冒充真实用量

### DeepSeek 余额为空

- 检查 API Key 是否有效
- 检查是否能访问 `https://api.deepseek.com/user/balance`
- 某些网络环境下需要配置代理

## 修改原则

- 保持 local-first 与默认私有。
- 新增数据源时增加配置项和失败降级，不能因为一个源缺失导致整个看板不可用。
- 不破坏现有 `/health`、`/api/stats`、`/widget` 和 `/` 路由。
- 完成前运行语法检查和健康接口测试。